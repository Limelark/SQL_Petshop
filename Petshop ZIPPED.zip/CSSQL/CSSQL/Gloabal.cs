﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSSQL
{
    internal class Global
    {
        public static int userID { get; set; }
        public static string productName { get; set; }
    }
}
