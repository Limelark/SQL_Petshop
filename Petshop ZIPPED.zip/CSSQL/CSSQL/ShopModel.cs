﻿namespace CSSQL
{
    public class ShopModel
    {
        public int ID { get; set; }
        public string address { get; set; }
        public int zipcode { get; set; }
        public string cityName { get; set; }
    }
}